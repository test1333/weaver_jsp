package gvo.ec.invoice;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ibm.db2.jcc.c.uf;

import gvo.ec.project.InsertUtil;
import weaver.conn.RecordSet;
import weaver.formmode.setup.ModeRightInfo;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class DeleteEInvoiceAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt = new RecordSet();
		InsertUtil iu = new InsertUtil();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		String now = sf.format(new Date());
		String sql_dt = "";
		String tableName = "";
		String mainID = "";
		String requestmark="";//���̱��
		String creater ="";
		String fplx="";//��Ʊ����
		String fphm="";//��Ʊ����
		String dtid="";
		String bs="";//��ʶ
		String invoiceid="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id from "+tableName+" where requestid="+requestid;
		
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
		}
		sql="select requestmark,creater from workflow_requestbase where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			requestmark = Util.null2String(rs.getString("requestmark"));
			creater = Util.null2String(rs.getString("creater"));
		}
		sql="delete from uf_e_invoice where xglc='"+requestid+"'";
		rs.executeSql(sql);
		return SUCCESS;
	}
}
