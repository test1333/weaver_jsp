package gvo.ec.service;

import gvo.ec.service.CreateRequestServiceOAStub.CreateHR015Service;
import gvo.ec.service.CreateRequestServiceOAStub.CreateHR015ServiceResponse;

import org.json.JSONException;
import org.json.JSONObject;

import weaver.conn.RecordSet;
import weaver.general.BaseBean;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class CreateOAHR015Action implements Action{
	
	BaseBean log = new BaseBean();
	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID = "";
		String reqman = "";//������Ա
		String mnyBearPsn = "";//���óе���
		String reqdate = "";//��������
		String businessTripRange = "";//���Χ
		String mnyBearDept = "";//���óе�����
		String reqsub = "";//�����ֲ�
		String eeramt = "";//������
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,reqman,mnyBearPsn,reqdate��businessTripRange,mnyBearDept,reqsub,eeramt from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			reqman = getcode(Util.null2String(rs.getString("reqman")),"1");
			mnyBearPsn =  getcode(Util.null2String(rs.getString("mnyBearPsn")),"1");
			reqdate = Util.null2String(rs.getString("reqdate"));
			businessTripRange = Util.null2String(rs.getString("businessTripRange"));
			mnyBearDept = getcode(Util.null2String(rs.getString("mnyBearDept")),"2");
			reqsub = getcode(Util.null2String(rs.getString("reqsub")),"3");
			eeramt = Util.null2String(rs.getString("eeramt"));
		}
		 JSONObject json = new JSONObject();
	     JSONObject header = new JSONObject();
	 	 JSONObject details = new JSONObject();
	 	
		 try {
			json.put("DETAILS", details);
			 json.put("HEADER", header);
			 header.put("reqman", reqman);
			 header.put("mnyBearPsn", mnyBearPsn);
			 header.put("reqdate", reqdate);
			 header.put("businessTripRange", businessTripRange);
			 header.put("mnyBearDept", mnyBearDept);
			 header.put("reqsub", reqsub);
			 header.put("eeramt", eeramt);
			 header.put("ecrqid", requestid);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.writeLog("ƴװjsonʧ��");
		}
		 try {
			String result=doService(reqman,json.toString());
			log.writeLog("����webservice��� requestid="+requestid+" message:"+result);
			 JSONObject json1 = new JSONObject(result);
			 String oarqid = json1.getString("OA_ID");
			 sql="update "+ tableName +" set oarqid='"+oarqid+"' where requestid="+requestid;
			 rs.executeSql(sql);
		 } catch (Exception e) {
			log.writeLog("����webserviceʧ�� requestid:"+requestid+" error:"+e.getMessage());
		}
		return SUCCESS;
	}
  
	  public String getcode(String id,String type){
		  RecordSet rs = new RecordSet();
		  String code="";
		  String sql="";
		  if("".equals(id)){
			  return "";
		  }
		  if("1".equals(type)){
		    sql="select workcode  as code from hrmresource where id="+id;
		  }else if("2".equals(type)){
			sql="select departmentcode as code from hrmdepartment where id="+id;	  
		  }else{
			  sql="select subcompanycode as code from hrmsubcompany where id="+id;	    
		  }
		  rs.executeSql(sql);
		  if(rs.next()){
			  code = Util.null2String(rs.getString("code"));
		  }
		  return code;
	  }
	  
	  public String doService(String workcode,String json) throws Exception{
		  CreateRequestServiceOAStub aa= new CreateRequestServiceOAStub();
		  CreateHR015Service chs= new CreateRequestServiceOAStub.CreateHR015Service();
		  chs.setWorkcode(workcode);
		  chs.setDataInfo(json);
		  CreateHR015ServiceResponse  cr=aa.CreateHR015Service(chs);
		  return cr.getOut();
	  }
}
