package gvo.ec.money;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateUnitCodeAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		// TODO Auto-generated method stub
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID = "";
		String unitcode="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
		}
		sql="select unitcode from "+tableName+"_dt3 where mainid="+mainID+" and rownum=1";
		rs.executeSql(sql);
		if(rs.next()){
			unitcode = Util.null2String(rs.getString("unitcode"));
		}
		sql="update "+tableName+" set corpno='"+unitcode+"' where requestid="+requestid;
		rs.executeSql(sql);
		return SUCCESS;
	}

}
