package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleaseBudgetforsbAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt = new RecordSet();
		String tableName = "";
		String mainID = "";
		String projectType="";//��Ŀ����
		String sblxje="";////�豸������
		String sbfl="";//�豸����
		String sfxysfys="";//�Ƿ���Ҫ�ͷ�Ԥ��
		String sql_dt="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,projectType,sblxje,sbfl,sfxysfys from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			projectType = Util.null2String(rs.getString("projectType"));
			sblxje = Util.null2String(rs.getString("sblxje"));
			sbfl = Util.null2String(rs.getString("sbfl"));
			sfxysfys = Util.null2String(rs.getString("sfxysfys"));
		}
		if("1".equals(projectType)&& "0".equals(sfxysfys)){
			sql="update uf_equipment_budget set syys=nvl(syys,0)+'"+sblxje+"'  where id='"+sbfl+"'";
			rs.executeSql(sql);
			sql="update uf_equipment_budget set yyys=nvl(ys,0)-nvl(syys,0) where id='"+sbfl+"'";
			rs.executeSql(sql);
			sql="update "+tableName+" set sfxysfys='1' where requestid="+requestid;
			rs.executeSql(sql);
			
			
		}
		return SUCCESS;
	}

}
