package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class CutPurCardMoneyAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID = "";
		String dingd="";//�ɹ�����
		String htjfbcje="";//��ͬ����֧�����
		String fklxnew="";//��������
		String htmc1="";//��ͬ����1
		String bxje="";//�������
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,dingd,htjfbcje,fklxnew,htmc1,bxje from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			dingd = Util.null2String(rs.getString("dingd"));
			htjfbcje = Util.null2String(rs.getString("htjfbcje"));
			fklxnew = Util.null2String(rs.getString("fklxnew"));
			htmc1 = Util.null2String(rs.getString("htmc1"));
			bxje = Util.null2String(rs.getString("bxje"));
		}
		if("".equals(htjfbcje)){
			htjfbcje="0";
		}
		if("".equals(bxje)){
			bxje="0";
		}
		if(!"".equals(dingd)){
			if("0".equals(fklxnew)||"2".equals(fklxnew)){
			sql="update uf_pocard set fkspzje=nvl(fkspzje,0)-'"+htjfbcje+"',ddyzfje=nvl(ddyzfje,0)+'"+htjfbcje+"' where id='"+dingd+"'";
			rs.executeSql(sql);
			}
			if("1".equals(fklxnew)||"2".equals(fklxnew)){
				sql="update uf_pocard set ljbxje=nvl(ljbxje,0)+"+bxje+" where id="+dingd; 
				rs.executeSql(sql);
			}
		}
		if(!"".equals(htmc1)){
			if("0".equals(fklxnew)||"2".equals(fklxnew)){
				sql="update uf_Nonproject set ljzfje=nvl(ljzfje,0)+"+htjfbcje+" where id="+htmc1; 
				rs.executeSql(sql);
			}
			if("1".equals(fklxnew)||"2".equals(fklxnew)){
				sql="update uf_Nonproject set ljbxje=nvl(ljbxje,0)+"+bxje+" where id="+htmc1; 
				rs.executeSql(sql);
			}
		}
		return SUCCESS;
	}

}
