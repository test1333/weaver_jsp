package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.BaseBean;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class CutBudgetforsbAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		BaseBean log = new BaseBean();
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt = new RecordSet();
		String tableName = "";
		String mainID = "";
		String projectType="";//��Ŀ����
		String sblxje="";//�豸������
		String sbfl="";//�豸����
		
		String sql_dt="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		//log.writeLog("kaishiceshi");
		sql="select id,projectType,sblxje,sbfl from "+tableName+" where requestid="+requestid;
		//log.writeLog("kaishiceshi sql"+sql);
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			projectType = Util.null2String(rs.getString("projectType"));
			sblxje = Util.null2String(rs.getString("sblxje"));
			sbfl = Util.null2String(rs.getString("sbfl"));
		}
		if("".equals(sblxje)){
			sblxje="0";
		}
		if("1".equals(projectType)){
			double usableamt =0.00;
			sql="select  nvl(syys,0)-'"+sblxje+"' as usableamt from uf_equipment_budget where id='"+sbfl+"'";
			rs.executeSql(sql);
			if(rs.next()){
				usableamt = rs.getDouble("usableamt");
			}
			if(usableamt<0){
				info.getRequestManager().setMessageid(System.currentTimeMillis()+"");            
				info.getRequestManager().setMessagecontent("�豸Ԥ��ʣ�����������ϵ����Ա");
				return SUCCESS;
			}
			sql="update uf_equipment_budget set syys=nvl(syys,0)-'"+sblxje+"'  where id='"+sbfl+"'";
			rs.executeSql(sql);
			sql="update uf_equipment_budget set yyys=nvl(ys,0)-nvl(syys,0) where id='"+sbfl+"'";
			rs.executeSql(sql);
			sql="update "+tableName+" set sfxysfys='0' where requestid="+requestid;
			rs.executeSql(sql);
		}
		sql="update "+tableName+" set sfcg='1' where requestid="+requestid;
		rs.executeSql(sql);
		return SUCCESS;
	}

}
