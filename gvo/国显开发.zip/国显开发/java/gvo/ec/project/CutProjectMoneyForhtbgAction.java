package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.BaseBean;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class CutProjectMoneyForhtbgAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		BaseBean log = new BaseBean();
		String tableName = "";
		String mainID = "";
		String xzht="";
		String bgce="";
		String bg5="";
		log.writeLog("testaa+sql");
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,xzht,bgce,bg5 from "+tableName+" where requestid="+requestid;
		log.writeLog("testaa+sql"+sql);
		rs.executeSql(sql);
		if(rs.next()){
			mainID = Util.null2String(rs.getString("id"));
			xzht = Util.null2String(rs.getString("xzht"));
			bgce = Util.null2String(rs.getString("bgce"));
			bg5 = Util.null2String(rs.getString("bg5"));
		}
		if("".equals(bgce)){
			bgce="0";
		}
		if("0".equals(bg5)){
			sql="update uf_project1 set sylxje =nvl(sylxje,0) -'"+bgce+"',hrljwf=nvl(hrljwf,0)+'"+bgce+"' where id=( select xmmc from uf_projectcontra where id="+xzht+")";
		    rs.executeSql(sql);
		}
		return SUCCESS;
	}

}
