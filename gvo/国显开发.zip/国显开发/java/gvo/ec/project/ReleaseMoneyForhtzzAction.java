package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleaseMoneyForhtzzAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID="";
		String xzht="";
		String syje="";
		String xmmc="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,xzht from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			xzht = Util.null2String(rs.getString("xzht"));
		}
		if(!"".equals(xzht)){
			sql="select nvl(htje,0)-nvl(htyfje,0) as syje,xmmc from uf_ProjectContra where id="+xzht;
			rs.executeSql(sql);
			if(rs.next()){
				syje = Util.null2String(rs.getString("syje"));
				xmmc = Util.null2String(rs.getString("xmmc"));
			}
			if(!"".equals(xmmc)){
			sql="update uf_project1 set sylxje=nvl(sylxje,0)+'"+syje+"',hrljwf=nvl(hrljwf,0)-'"+syje+"' where id="+xmmc;
			rs.executeSql(sql);
			}
			
		}
		return SUCCESS;
	}

}
