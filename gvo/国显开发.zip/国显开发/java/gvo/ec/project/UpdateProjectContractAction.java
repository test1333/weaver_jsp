package gvo.ec.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import weaver.conn.RecordSet;
import weaver.formmode.setup.ModeRightInfo;
import weaver.general.BaseBean;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateProjectContractAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String tableName = "";
		String mainID = "";
		String xzht="";
		String bgce="";
		String sql_dt="";
		String bg5="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,xzht,bgce,bg5 from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID = Util.null2String(rs.getString("id"));
			xzht = Util.null2String(rs.getString("xzht"));
			bgce = Util.null2String(rs.getString("bgce"));
			bg5 = Util.null2String(rs.getString("bg5"));
		}
		if("".equals(bgce)){
			bgce="0";
		}
		if(!"".equals(xzht)){
			String createrid=insertHistory("-63", "uf_ProjectContra",
					"id", xzht);
			sql = "select Max(id) as billid from uf_ProjectContra where superid = " + xzht;
			rs.executeSql(sql);
			String historyId = "";
			if (rs.next()) {
				historyId = Util.null2String(rs.getString("billid"));
				ModeRightInfo ModeRightInfo = new ModeRightInfo();
				ModeRightInfo.editModeDataShare(Integer.valueOf(createrid),41,
						Integer.valueOf(historyId));
			}
			
		    if(!"".equals(historyId)){
		    	sql="insert into uf_projectcontra_dt1(mainid,jd,bl,je,fklx,fphm,fplx,ljbxje,bcbxje,ljzfje,bcfkje,yfje,fkrq,sfyfk) (select * from (select "+historyId+",jd,bl,je,fklx,fphm,fplx,ljbxje,bcbxje,ljzfje,bcfkje,yfje,fkrq,sfyfk from uf_projectcontra_dt1 where mainid="+xzht+" order by id asc ))";
		    	rs.executeSql(sql);
		    }
		}
		String version="0";
		sql="select nvl(version,1)+1 as version from uf_projectcontra where id="+xzht;
		rs.executeSql(sql);
		if(rs.next()){
			version=Util.null2String(rs.getString("version"));
		}
		sql="select * from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			Map<String, String> mapStr = new HashMap<String, String>();
//			if("0".equals(Util.null2String(rs.getString("bg1")))){
//				mapStr.put("htmc", Util.null2String(rs.getString("bghhtmc")));// ������ͬ����
//			}
//			if("0".equals(Util.null2String(rs.getString("bg2")))){
//				mapStr.put("htbh", Util.null2String(rs.getString("bghhtbh")));// ������ͬ���
//			}
//			if("0".equals(Util.null2String(rs.getString("bg3")))){
//				mapStr.put("htdf", Util.null2String(rs.getString("bgh")));// ������ͬ�Է�
//			}
			if("0".equals(Util.null2String(rs.getString("bg4")))){
				mapStr.put("hksktj", Util.null2String(rs.getString("bghhtdf")));// ����󸶿�/�տ�����
			}
			if("0".equals(Util.null2String(rs.getString("bg5")))){
				mapStr.put("htje", Util.null2String(rs.getString("bghhksktj")));// ������ͬ���
				mapStr.put("jswrmbje", Util.null2String(rs.getString("bghjswrmbje")));// ��������Ϊ����ҽ��
				mapStr.put("se", Util.null2String(rs.getString("bghse")));// �����˰��
			    //sql_dt="update uf_project1 set sylxje =sylxje -"+bgce+" where id=( select xmmc from uf_projectcontra where id="+xzht+")";
			    //rs_dt.executeSql(sql_dt);
			}
//			if("0".equals(Util.null2String(rs.getString("bg6")))){
//				mapStr.put("htjebz", Util.null2String(rs.getString("bghhtjebz")));//������ͬ������
//			}
//			if("0".equals(Util.null2String(rs.getString("bg7")))){
//				mapStr.put("hl", Util.null2String(rs.getString("bghhl")));// ��������
//			}
//			if("0".equals(Util.null2String(rs.getString("bg8")))){
//				mapStr.put("jswrmbje", Util.null2String(rs.getString("bghjswrmbje")));// ��������Ϊ����ҽ��
//			}
			if("0".equals(Util.null2String(rs.getString("bg6")))){
				mapStr.put("htksrq", Util.null2String(rs.getString("bghhtksrq")));// ������ͬ����
				mapStr.put("htjsrq", Util.null2String(rs.getString("bghhtjsrq")));// ������ͬ��������
			}
			if("0".equals(Util.null2String(rs.getString("bg7")))){
				mapStr.put("htxz", Util.null2String(rs.getString("bghhtxz")));// ������ͬ����
			}
			if("0".equals(Util.null2String(rs.getString("bg8")))){
				mapStr.put("skf", Util.null2String(rs.getString("bghskf")));// ������տ			
				mapStr.put("skzh", Util.null2String(rs.getString("bghskzh")));// ������տ��˺�			
				mapStr.put("hm", Util.null2String(rs.getString("bghhm")));// �������			
				mapStr.put("khh", Util.null2String(rs.getString("bghkhh")));//����󿪻���
			}
			mapStr.put("htfj", Util.null2String(rs.getString("htfj3")));
			mapStr.put("version", version);
			mapStr.put("xglc", requestid);
			iu.updateGen(mapStr, "uf_projectcontra", "id", xzht);
			sql="delete from uf_projectcontra_dt1 where mainid="+xzht+" and  sfyfk is null and id not in(select superid from "+tableName+"_dt1 where mainid="+mainID+" and superid is not null )";
			rs.executeSql(sql);
			sql="update uf_projectcontra_dt1 a set (jd,bl,je,fkrq) =(select b.jd,b.bl,b.je1,b.fksq from "+tableName+"_dt1 b where b.mainid="+mainID+" and a.id=b.superid  ) where a.mainid="+xzht+" and a.sfyfk is null  ";
			rs.executeSql(sql);
			sql="insert into uf_projectcontra_dt1(mainid,jd,bl,je,fkrq) (select * from (select "+xzht+",jd,bl,je1,fksq from "+tableName+"_dt1 where mainid="+mainID+" and superid is null order by id asc))";
			rs.executeSql(sql);
//			if("0".equals(bg5)){
//				sql="update uf_ProjectContra set se=nvl((select fhhbfb from uf_taxpoint where id=htjezshs),0)*nvl(jswrmbje,0) where id="+xzht;
//				rs.executeSql(sql);
//			}
			
		}
		
	    
		return SUCCESS;
	}
	
public String insertHistory(String billid,String table_name,String uqField,String uqVal) {
		
		BaseBean log  = new BaseBean();
		RecordSet rs = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String createrid="";

		// ��� �����ֶ�
		List<String> list = new ArrayList<String>();
 		String sql = "select fieldname from workflow_billfield where billid="+billid+" order by dsporder";
 	//	log.writeLog("insertNow(1) = " + sql);
		rs.executeSql(sql);
		while(rs.next()){
			String tmp_1 = Util.null2String(rs.getString("fieldname"));
			
			// ���������ų�
			if(!"".equals(tmp_1)&&!"superid".equalsIgnoreCase(tmp_1)){
				list.add(tmp_1);
			}
		}
		if(!"".equals(table_name)){
			
			Map<String, String> mapStr = new HashMap<String, String>();
			
			sql = "select * from "+table_name+"  where "+uqField+"='"+uqVal+"'";
		//	log.writeLog("insertNow(2) = " + sql);
			rs.execute(sql);
			if(rs.next()){
				// ѭ����ȡ   ��Ϊ��ֵ����ϳ�sql
				for(String field : list){
					String tmp_x = Util.null2String(rs.getString(field));
					if(tmp_x.length() > 0)
						mapStr.put(field, tmp_x);
				}
			}
			createrid=rs.getString("modedatacreater");
			// �����Ҫ���������id
			if(mapStr.size() > 0){
				mapStr.put("superid", Util.null2String(rs.getString("ID")));
				// ���������id
				mapStr.put("requestid", Util.null2String(rs.getString("requestid")));
				mapStr.put("modedatacreater", Util.null2String(rs.getString("modedatacreater")));
				mapStr.put("modedatacreatertype", Util.null2String(rs.getString("modedatacreatertype")));
				mapStr.put("formmodeid", Util.null2String(rs.getString("formmodeid")));				
				iu.insert(mapStr, table_name);
			}
		}
		
		return createrid;
	}

}
