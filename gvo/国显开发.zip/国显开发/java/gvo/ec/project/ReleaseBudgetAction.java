package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleaseBudgetAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt = new RecordSet();
		String tableName = "";
		String mainID = "";
		String projectType="";//��Ŀ����
		String lxje="";//������
		String eqtype="";//��Ŀ�豸����
		String lxje_dt="";//��ϸ������
		String eqtype_dt="";//��ϸ��Ŀ�豸����
		String sfxysfys="";//�Ƿ���Ҫ�ͷ�Ԥ��
		String sql_dt="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,projectType,lxje,eqtype,sfxysfys from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			projectType = Util.null2String(rs.getString("projectType"));
			lxje = Util.null2String(rs.getString("lxje"));
			eqtype = Util.null2String(rs.getString("eqtype"));
			sfxysfys = Util.null2String(rs.getString("sfxysfys"));
		}
		if(!"1".equals(projectType)){
			
			sql="update uf_projectBudget set usableamt=usableamt+'"+lxje+"'  where equipmentname='"+eqtype+"'";
			rs.executeSql(sql);
			sql="update uf_projectBudget set usedamt=nvl(budgetamt,0)-nvl(usableamt,0) where equipmentname='"+eqtype+"'";
			rs.executeSql(sql);
		}
		
		if("1".equals(projectType)&& "0".equals(sfxysfys)){
			sql="select eqyipment,lxje from "+tableName+"_dt1 where mainid="+mainID;
			rs.executeSql(sql);
			while(rs.next()){
				lxje_dt = Util.null2String(rs.getString("lxje"));
				eqtype_dt= Util.null2String(rs.getString("eqyipment"));
				
				sql_dt="update uf_projectBudget set usableamt=usableamt+'"+lxje_dt+"'  where equipmentname='"+eqtype_dt+"'";
				rs_dt.executeSql(sql_dt);
				sql_dt="update uf_projectBudget set usedamt=nvl(budgetamt,0)-nvl(usableamt,0) where equipmentname='"+eqtype_dt+"'";
				rs_dt.executeSql(sql_dt);
			}
			sql="update "+tableName+" set sfxysfys='1' where requestid="+requestid;
			rs.executeSql(sql);
			
		}
		return SUCCESS;
	}

}
