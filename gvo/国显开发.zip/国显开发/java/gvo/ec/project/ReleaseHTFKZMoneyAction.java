package gvo.ec.project;

import java.util.HashMap;
import java.util.Map;

import weaver.conn.RecordSet;
import weaver.formmode.setup.ModeRightInfo;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleaseHTFKZMoneyAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt1 = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String tableName = "";
		String mainID = "";
		String xzht="";
		String htbczfje="";//����֧�����

		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,htbczfje,xzht,sfzhfk,sfyyjs,xgjssp,jsje,chtjsje,sjjsje,txr,htdf,dhhbfb,htjezshs from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			xzht = Util.null2String(rs.getString("xzht"));
			htbczfje = Util.null2String(rs.getString("htbczfje"));
			
		}
		if("".equals(htbczfje)){
			htbczfje="0";
		}
	
	    sql="update uf_project1 set htfkz=nvl(htfkz,0)-'"+htbczfje+"',hrljwf=nvl(hrljwf,0)+'"+htbczfje+"' where id=( select xmmc from uf_projectcontra where id="+xzht+")"; 	
	    rs.executeSql(sql);
		return SUCCESS;
	}

}
