package gvo.ec.project;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateProjectInfoAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String tableName = "";
		String mainID = "";
		String xmmc="";//��Ŀ����
		String bglx="";//�������
		String xmjhkssj2 = "";//����Ŀ�ƻ���ʼʱ��
		String xmjhjssj2 = "";//����Ŀ�ƻ�����ʱ��
		String lxje2 = "";//��������
		String newxmmc = "";//����Ŀ����
		String oldxmmc="";//ԭ��Ŀ����
		String oldlxje="";//ԭ������
		String projectPlanStartTime="";//ԭ��Ŀ�ƻ���ʼʱ��
		String projectPlanEndTime="";//ԭ��Ŀ�ƻ�����ʱ��
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		String now = sf.format(new Date());
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,xmmc,bglx,xmjhkssj2,xmjhjssj2,lxje2,newxmmc from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			xmmc = Util.null2String(rs.getString("xmmc"));
			bglx = Util.null2String(rs.getString("bglx"));
			xmjhkssj2 = Util.null2String(rs.getString("xmjhkssj2"));
			xmjhjssj2 = Util.null2String(rs.getString("xmjhjssj2"));
			lxje2 = Util.null2String(rs.getString("lxje2"));
			newxmmc = Util.null2String(rs.getString("newxmmc"));
		}
		sql="select xmmc,lxje,projectPlanStartTime,projectPlanEndTime from uf_project1 where id="+xmmc;
		rs.executeSql(sql);
		if(rs.next()){
			oldxmmc = Util.null2String(rs.getString("xmmc"));
			oldlxje = Util.null2String(rs.getString("lxje"));
			projectPlanStartTime = Util.null2String(rs.getString("projectPlanStartTime"));
			projectPlanEndTime = Util.null2String(rs.getString("projectPlanEndTime"));
		}
		Map<String, String> mapStr = new HashMap<String, String>();
		if("0".equals(bglx)){//����			
			mapStr.put("mainid", xmmc);
			mapStr.put("ylxlc", requestid);
			mapStr.put("bgrq", now);//���ڲ���
			mapStr.put("yxmksrq", projectPlanStartTime);
			mapStr.put("ysmjsrq", projectPlanEndTime);
			mapStr.put("bghxmksrq", xmjhkssj2);
			mapStr.put("bghxmjsrq", xmjhjssj2);
			iu.insert(mapStr, "uf_project1_dt1");
			sql="update uf_project1 set projectPlanStartTime='"+xmjhkssj2+"',projectPlanEndTime='"+xmjhjssj2+"'  where id="+xmmc;
			rs.executeSql(sql);
		}else if("1".equals(bglx)){//���
			mapStr.put("mainid", xmmc);
			mapStr.put("ylxlc", requestid);
			mapStr.put("bgrq", now);
			mapStr.put("ylxje", oldlxje);
			mapStr.put("bghje", lxje2);
			iu.insert(mapStr, "uf_project1_dt1");
			sql="update uf_project1 set lxje='"+lxje2+"',sylxje=(nvl(sylxje,0)+("+lxje2+"-'"+oldlxje+"')) where id="+xmmc;
			rs.executeSql(sql);
		}else if("2".equals(bglx)){//����
			mapStr.put("mainid", xmmc);
			mapStr.put("ylxlc", requestid);
			mapStr.put("bgrq", now);
			mapStr.put("yxmmc", oldxmmc);
			mapStr.put("bghxmmc", newxmmc);
			iu.insert(mapStr, "uf_project1_dt1");
			sql="update uf_project1 set xmmc='"+newxmmc+"' where id="+xmmc;
			rs.executeSql(sql);
		}
	
		return SUCCESS;
	}

}
