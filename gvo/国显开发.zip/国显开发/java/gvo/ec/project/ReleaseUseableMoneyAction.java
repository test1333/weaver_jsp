package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleaseUseableMoneyAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID = "";
		String xmmc="";//��Ŀ����
		String jswrmbje="";//����Ϊ����ҽ��
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,xmmc,jswrmbje from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			xmmc = Util.null2String(rs.getString("xmmc"));
			jswrmbje = Util.null2String(rs.getString("jswrmbje"));
		}
		
		sql="update uf_project1 set sylxje=nvl(sylxje,0)+'"+jswrmbje+"',hrljwf=nvl(hrljwf,0)-'"+jswrmbje+"'  where id='"+xmmc+"'";
		rs.executeSql(sql);
		return SUCCESS;
	}

}
