package gvo.ec.project;

import java.util.HashMap;
import java.util.Map;

import weaver.conn.RecordSet;
import weaver.formmode.setup.ModeRightInfo;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateContractMoneyAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt1 = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String tableName = "";
		String mainID = "";
		String xzht="";
		String htbczfje="";//����֧�����
		String sfzhfk="";//�Ƿ����ո���
		String htyfje="";//��Ƭ-��ͬ��֧�����
		String htje="";//��Ƭ-��ͬ���
		String syje="";//��Ƭ-ʣ����
		String xmmc="";//��Ŀ����
		String mxid_dt="";//��Ŀ��Ƭ��ϸid
		String bcbxje_dt="";//��ϸ-���α������
		String bcfkje_dt="";//��ϸ-���θ�����
		String sfyyjs="";//�Ƿ����н�����������
		String xgjssp = "";//��ؽ�����������
		String jsje = "";//������
		String chtjsje = "";//����ͬ������
		String sjjsje = "";//ʵ�ʽ�����
		String fklx_dt="";//�������
		String fphm_dt="";//��Ʊ����
		String fpdm_dt="";//��Ʊ����
		String fplx_dt="";//��Ʊ����
		String txr="";//��д��
		String htdf="";//��ͬ�Է�
		String dhhbfb="";//�һ���ٷֱ�
		String htjezshs	="";
		String tax="";
		String notaxamount="";
		String dtid="";
		String sql_dt="";
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,htbczfje,xzht,sfzhfk,sfyyjs,xgjssp,jsje,chtjsje,sjjsje,txr,htdf,dhhbfb,htjezshs from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			xzht = Util.null2String(rs.getString("xzht"));
			htbczfje = Util.null2String(rs.getString("htbczfje"));
			sfzhfk = Util.null2String(rs.getString("sfzhfk"));
			sfyyjs = Util.null2String(rs.getString("sfyyjs"));
			xgjssp = Util.null2String(rs.getString("xgjssp"));
			jsje = Util.null2String(rs.getString("jsje"));
			chtjsje = Util.null2String(rs.getString("chtjsje"));
			sjjsje = Util.null2String(rs.getString("sjjsje"));
			txr = Util.null2String(rs.getString("txr"));
			htdf = Util.null2String(rs.getString("htdf"));
			dhhbfb = Util.null2String(rs.getString("dhhbfb"));
			htjezshs = Util.null2String(rs.getString("htjezshs"));
		}
		if("".equals(htbczfje)){
			htbczfje="0";
		}
		if("".equals(dhhbfb)){
			dhhbfb="0";
		}
		sql="select  nvl(htje,0) as htje,nvl(htyfje,0)+"+htbczfje+" as htyfje,nvl(htje,0)-(nvl(htyfje,0)+"+htbczfje+") as syje,xmmc from uf_ProjectContra where id="+xzht;
		rs.executeSql(sql);
		if(rs.next()){
			htyfje = Util.null2String(rs.getString("htyfje"));
			htje = Util.null2String(rs.getString("htje"));
			syje = Util.null2String(rs.getString("syje"));
			xmmc = Util.null2String(rs.getString("xmmc"));
		}
		Map<String, String> mapStr = new HashMap<String, String>();
		
		mapStr.put("htyfje", htyfje);
		
		mapStr.put("sfzhfk", sfzhfk);
		mapStr.put("sfyyjs", sfyyjs);
		mapStr.put("xgjssp", xgjssp);
		mapStr.put("jsje", jsje);
		mapStr.put("chtjsje", chtjsje);
		mapStr.put("sjjsje", sjjsje);
		if("0".equals(sfyyjs)){
			if("".equals(jsje)){
				jsje="0";
			}
			if(!"".equals(xmmc)){
				sql="update uf_project1 set sylxje=nvl(sylxje,0)-("+jsje+"-'"+htje+"') where id="+xmmc;
				rs.executeSql(sql);
				if(Float.parseFloat(jsje)-Float.parseFloat(htje)>0){
					sql="update uf_project1 set htljyf=nvl(htljyf,0)+("+jsje+"-'"+htje+"') where id="+xmmc;
					rs.executeSql(sql);
				}else{
					sql="update uf_project1 set hrljwf=nvl(hrljwf,0)+("+jsje+"-'"+htje+"') where id="+xmmc;
					rs.executeSql(sql);
				}
				
			}
			mapStr.put("htzt", "1");
		}else{
			if("0".equals(sfzhfk)){
				if(!"".equals(xmmc)){
					sql="update uf_project1 set sylxje=nvl(sylxje,0)+'"+syje+"',hrljwf=nvl(hrljwf,0)-'"+syje+"' where id="+xmmc;
					rs.executeSql(sql);
				}
				mapStr.put("htzt", "1");
			}else{
				mapStr.put("htzt", "0");
			}
		}
		sql="update uf_project1 set htfkz=nvl(htfkz,0)-'"+htbczfje+"',htljyf=nvl(htljyf,0)+'"+htbczfje+"' where id="+xmmc;
		rs.executeSql(sql);
		
		iu.updateGen(mapStr, "uf_projectcontra", "id", xzht);
		sql="select id,mxid,bcbxje,bcfkje,fklx,fphm,fpdm,fplx from "+tableName+"_dt1 where mainid="+mainID;
		rs.executeSql(sql);
		while(rs.next()){
			dtid = Util.null2String(rs.getString("id"));
			mxid_dt=Util.null2String(rs.getString("mxid"));
			bcbxje_dt = Util.null2String(rs.getString("bcbxje"));
			bcfkje_dt = Util.null2String(rs.getString("bcfkje"));
			fklx_dt = Util.null2String(rs.getString("fklx"));
			fphm_dt = Util.null2String(rs.getString("fphm"));
			fpdm_dt = Util.null2String(rs.getString("fpdm"));
			fplx_dt = Util.null2String(rs.getString("fplx"));
			if("".equals(bcbxje_dt)){
				bcbxje_dt="0";
			}
			if("".equals(bcfkje_dt)){
				bcfkje_dt="0";
			}
			if(!"".equals(mxid_dt)){
			sql_dt="update uf_ProjectContra_dt1 set ljbxje=nvl(ljbxje,0)+'"+bcbxje_dt+"',yfje=nvl(yfje,0)+'"+bcfkje_dt+"' where id="+mxid_dt;
			rs_dt1.executeSql(sql_dt);
			sql_dt="update uf_ProjectContra_dt1 set sfyfk='0' where  yfje=je and id="+mxid_dt;
			rs_dt1.executeSql(sql_dt);
			}
			if("0".equals(fklx_dt)||"1".equals(fklx_dt)){
				
				sql_dt="select round("+bcbxje_dt+"*"+dhhbfb+",2) as tax ,round("+bcbxje_dt+"- round("+bcbxje_dt+"*"+dhhbfb+",2),2) as notaxamount  from dual";
				rs_dt1.executeSql(sql_dt);
				if(rs_dt1.next()){
					tax = Util.null2String(rs_dt1.getString("tax"));
					notaxamount = Util.null2String(rs_dt1.getString("notaxamount"));
				}
				String bh=requestid+"_"+dtid;
				Map<String, String> mapStr1 = new HashMap<String, String>();
				mapStr1.put("invoicenum", fphm_dt);
				mapStr1.put("invoicecode", fpdm_dt);
				mapStr1.put("drowbill", htdf);
				mapStr1.put("invoicetype", fplx_dt);
				mapStr1.put("taxamount", bcbxje_dt);
				mapStr1.put("taxrate", htjezshs);
				mapStr1.put("tax", tax);
				mapStr1.put("notaxamount", notaxamount);
				mapStr1.put("relevantflow", requestid);
				mapStr1.put("bh", bh);
				mapStr1.put("modedatacreater", txr);
				mapStr1.put("modedatacreatertype", "0");
				mapStr1.put("formmodeid", "181");
				iu.insert(mapStr1, "uf_invoice");
				String billid="";
				sql_dt="select id from uf_invoice where bh='"+bh+"'";
				rs_dt1.executeSql(sql_dt);
				if(rs_dt1.next()){
					billid = Util.null2String(rs_dt1.getString("id"));
				}
				ModeRightInfo ModeRightInfo = new ModeRightInfo();
				ModeRightInfo.editModeDataShare(Integer.valueOf(txr), 181,
					Integer.valueOf(billid));
			}
			
		}
		
		return SUCCESS;
	}

}
