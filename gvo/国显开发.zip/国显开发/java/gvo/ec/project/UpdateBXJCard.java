package gvo.ec.project;

import java.util.HashMap;
import java.util.Map;

import weaver.conn.RecordSet;
import weaver.formmode.setup.ModeRightInfo;
import weaver.general.BaseBean;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateBXJCard implements Action{

	@Override
	public String execute(RequestInfo info) {

		BaseBean log = new BaseBean();
		String workflowID = info.getWorkflowid();
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String sql = "";
		String tableName = "";
		String sqr = "";
		String yghm = "";
		String khh = "";
		String yyzh = "";
		String lhh = "";
		String num = "";
		String sqrq = "";
		String table_id = "";
		
		log.writeLog("----------���±�������Ϣ����----------");
		sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		log.writeLog("sql----------" + sql);
		rs.execute(sql);		
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		
		sql = "select sqr,yghm,khh,yhzh,lhh,sqrq from "+tableName+" where requestid="+requestid;
		log.writeLog("sql----------" + sql);
		rs.execute(sql);		
		if (rs.next()) {
			sqr = Util.null2String(rs.getString("sqr"));
			yghm = Util.null2String(rs.getString("yghm"));
			khh = Util.null2String(rs.getString("khh"));
			yyzh = Util.null2String(rs.getString("yhzh"));
			lhh = Util.null2String(rs.getString("lhh"));
			sqrq = Util.null2String(rs.getString("sqrq"));
		}
		
		sql = "select count(*) as num from uf_bxjkb where ygxm="+sqr;
		log.writeLog("sql----------" + sql);
		rs.execute(sql);		
		if (rs.next()) {
			num = Util.null2String(rs.getString("num"));
		}
		if ("0".equals(num)){
			Map<String, String> mapStr = new HashMap<String, String>();
			mapStr.put("ygxm", sqr); 
			mapStr.put("yghm", yghm);
			mapStr.put("khh", khh);
			mapStr.put("yyzh", yyzh);
			mapStr.put("lhh", lhh);
			
			mapStr.put("modedatacreater", sqr);
			mapStr.put("modedatacreatertype", "0");
			mapStr.put("formmodeid", "241");
			mapStr.put("modedatacreatedate", sqrq);
			
			iu.insert(mapStr, "uf_bxjkb");
			
			sql="select id from uf_bxjkb where ygxm="+sqr;
			log.writeLog("sql----------" + sql);
			rs.executeSql(sql);
			if(rs.next()){
				table_id = Util.null2String(rs.getString("id"));
			}
			ModeRightInfo ModeRightInfo = new ModeRightInfo();
			ModeRightInfo.editModeDataShare(Integer.valueOf(sqr), 241,Integer.valueOf(table_id));
			
		}else{
			sql = "update uf_bxjkb set yghm='"+yghm+"',khh='"+khh+"',yhzh='"+yyzh+"',lhh='"+lhh+"' where ygxm="+sqr;
			log.writeLog("sql----------" + sql);
			rs.execute(sql);	
		}		
		log.writeLog("----------��������----------");	
		return SUCCESS;	
	}

}
