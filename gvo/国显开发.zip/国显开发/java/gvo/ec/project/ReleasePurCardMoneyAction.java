package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleasePurCardMoneyAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID = "";
		String dingd="";//�ɹ�����
		String fklxnew="";//��������
		String htjfbcje="";//��ͬ����֧�����
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,dingd,htjfbcje,fklxnew from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			dingd = Util.null2String(rs.getString("dingd"));
			htjfbcje = Util.null2String(rs.getString("htjfbcje"));
			fklxnew = Util.null2String(rs.getString("fklxnew"));
		}
		if("".equals(htjfbcje)){
			htjfbcje="0";
		}
		if("0".equals(fklxnew)||"2".equals(fklxnew)){
		sql="update uf_pocard set fkspzje=nvl(fkspzje,0)-'"+htjfbcje+"' where id='"+dingd+"'";
		rs.executeSql(sql);
		}
		return SUCCESS;
	}

}
