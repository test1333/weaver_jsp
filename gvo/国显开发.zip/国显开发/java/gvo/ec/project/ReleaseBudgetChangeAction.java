package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.BaseBean;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class ReleaseBudgetChangeAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		BaseBean log = new BaseBean();
		String tableName = "";
		String mainID = "";
		String et="";//��Ŀ�豸����
		String bgce="";//������
		String bglx="";//�������
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,et,bgce,bglx from "+tableName+" where requestid="+requestid;
		//log.writeLog("testaa+sql"+sql);
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			et = Util.null2String(rs.getString("et"));
			bgce = Util.null2String(rs.getString("bgce"));
			bglx = Util.null2String(rs.getString("bglx"));
		}
		if("1".equals(bglx)){
			sql="update uf_projectBudget set usableamt=usableamt+'"+bgce+"'  where equipmentname='"+et+"'";
			rs.executeSql(sql);
			sql="update uf_projectBudget set usedamt=nvl(budgetamt,0)-nvl(usableamt,0) where equipmentname='"+et+"'";
			rs.executeSql(sql);
		}
		return SUCCESS;
	}

}
