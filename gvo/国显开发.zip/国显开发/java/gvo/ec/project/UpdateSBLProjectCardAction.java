package gvo.ec.project;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateSBLProjectCardAction implements Action{

	@Override
	public String execute(RequestInfo info) {
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		RecordSet rs_dt = new RecordSet();
		InsertUtil iu = new InsertUtil();
		String tableName = "";
		String sql_dt="";
		String mainID = "";
		String bgce = "";
		String sbfl = "";
		String projectPlanStartTime="";
		String projectPlanEndTime="";
		String bgce_dt="";
		String xmmc="";
		String ysje="";
		String oldlxje="";
		String oldprojectPlanStartTime="";
		String oldprojectPlanEndTime="";
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		String now = sf.format(new Date());
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,bgce,sbfl from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			bgce = Util.null2String(rs.getString("bgce"));
			sbfl = Util.null2String(rs.getString("sbfl"));
		}
		if("".equals(bgce)){
			bgce="0";
		}
		sql="select * from "+tableName+"_dt1 where mainid="+mainID;
		rs.executeSql(sql);
		while(rs.next()){
			ysje=Util.null2String(rs.getString("ysje"));
			xmmc  = Util.null2String(rs.getString("xmmc"));
			bgce_dt =Util.null2String(rs.getString("bgce"));
			if("".equals(bgce_dt)){
				bgce_dt="0";
			}
			if("".equals(ysje)){
				ysje="0";
			}
			projectPlanStartTime =Util.null2String(rs.getString("projectPlanStartTime"));
			projectPlanEndTime =Util.null2String(rs.getString("projectPlanEndTime")); 
			sql_dt="select lxje,projectPlanStartTime,projectPlanEndTime from uf_project1 where id="+xmmc;;
			rs_dt.executeSql(sql_dt);
			if(rs_dt.next()){
				oldlxje = Util.null2String(rs_dt.getString("lxje"));
				oldprojectPlanStartTime =Util.null2String(rs_dt.getString("projectPlanStartTime"));
				oldprojectPlanEndTime =Util.null2String(rs_dt.getString("projectPlanEndTime")); 
			}
			Map<String, String> mapStr = new HashMap<String, String>();
			mapStr.put("mainid", xmmc);
			mapStr.put("ylxlc", requestid);
			mapStr.put("bgrq", now);//���ڲ���
			mapStr.put("yxmksrq", oldprojectPlanStartTime);
			mapStr.put("ysmjsrq", oldprojectPlanEndTime);
			mapStr.put("bghxmksrq", projectPlanStartTime);
			mapStr.put("bghxmjsrq", projectPlanEndTime);
			mapStr.put("ylxje", oldlxje);
			mapStr.put("bghje", ysje);
			iu.insert(mapStr, "uf_project1_dt1");
			sql="update uf_project1 set projectPlanStartTime='"+projectPlanStartTime+"',projectPlanEndTime='"+projectPlanEndTime+"',lxje='"+ysje+"',sylxje=(nvl(sylxje,0)+"+bgce_dt+")  where id="+xmmc;
			rs.executeSql(sql);
		}
		sql="update uf_equipment_budget set yyys=nvl(yyys,0)+"+bgce+",syys=nvl(syys,0)-"+bgce+" where id="+sbfl;
		rs.executeSql(sql);
		return SUCCESS;
	}

}
