package gvo.ec.project;

import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.interfaces.workflow.action.Action;
import weaver.soa.workflow.request.RequestInfo;

public class UpdateGZFJAction  implements Action{

	@Override
	public String execute(RequestInfo info) {
		// TODO Auto-generated method stub
		String workflowID = info.getWorkflowid();// ��ȡ��������Workflowid��ֵ
		String requestid = info.getRequestid();
		RecordSet rs = new RecordSet();
		String tableName = "";
		String mainID = "";
		String htkp1="";//������ͬ��Ƭ���������ࣩ
		String htkp2="";//������ͬ��Ƭ�������ࣩ
		String fryywj="";//��ӡ�ļ������°棩
		String sql = " Select tablename From Workflow_bill Where id in ("
				+ " Select formid From workflow_base Where id= " + workflowID
				+ ")";
		rs.execute(sql);
		if (rs.next()) {
			tableName = Util.null2String(rs.getString("tablename"));
		}
		sql="select id,htkp1,htkp2,fryywj from "+tableName+" where requestid="+requestid;
		rs.executeSql(sql);
		if(rs.next()){
			mainID= Util.null2String(rs.getString("id"));
			htkp1= Util.null2String(rs.getString("htkp1"));
			htkp2= Util.null2String(rs.getString("htkp2"));
			fryywj= Util.null2String(rs.getString("fryywj"));
		}
		if(!"".equals(htkp2)){
			sql="update uf_ProjectContra set htfjgz='"+fryywj+"' where id="+htkp2;
			rs.executeSql(sql);
		}
		if(!"".equals(htkp1)){
			sql="update uf_Nonproject set htfjgz='"+fryywj+"' where id="+htkp1;
			rs.executeSql(sql);
		}
		return SUCCESS;
	}

}
