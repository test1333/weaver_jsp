package gvo.webservice;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import weaver.general.Util;

public class GvoWebTest {
	
//	public static void main(String[] args){
//		String jsonStr="{'HEADER':{'BUKRS':'1000','BUTXT':'��ɽ���Թ�����޹�˾','LIFNR':'0001000614','NAME1':'��������˼�ظ��Ƽ����޹�˾','MATNR':'000000000100000161','MAKTX':'FOF-ACF_MF-531������ֱ��5��m������2.0mm�����35��m','ZRECOGNIZE':'��'}}";
//		JSONObject json = new JSONObject();
//		JSONObject header = new JSONObject();
//		JSONObject details = new JSONObject();
//		String BUKRS="";//��˾����
//		String BUTXT="";//��˾����
//		String LIFNR="";//��Ӧ��
//		String NAME1="";//��Ӧ������
//		String MATNR="";//���ϱ���
//		String MAKTX="";//��������
//		String ZRECOGNIZE = "";//�Ƿ����
//		
//		 try {
//			json.put("HEADER", header);
//			json.put("DETAILS", details);
//			JSONObject jo = new JSONObject(jsonStr);
//     		JSONObject head=jo.getJSONObject("HEADER");
//     		System.out.println(head.toString());
//     		BUKRS = head.getString("BUKRS");
//     		BUTXT = head.getString("BUTXT");
//     		LIFNR = head.getString("LIFNR");
//     		NAME1 = head.getString("NAME1");
//     		MATNR = head.getString("MATNR");
//     		MAKTX = head.getString("MAKTX");
//     		ZRECOGNIZE = head.getString("ZRECOGNIZE");
//     		
//     		header.put("companyCode", BUKRS);
//     		header.put("companyName", BUTXT);
//     		header.put("suppliers", LIFNR);
//     		header.put("supNames", NAME1);
//     		header.put("sapMaterial", MATNR);
//     		header.put("materName", MAKTX);
//     		header.put("suplStatus", ZRECOGNIZE);
//     		System.out.println(json.toString());
//     		
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//       	
//	}
	
	
//	public static void main(String[] args){
//		String jsonStr="{'HEADER':{'BUKRS':'1000','BUTXT':'��ɽ���Թ�����޹�˾','LIFNR':'0001000614','NAME1':'��������˼�ظ��Ƽ����޹�˾','MATNR':'000000000100000161','MAKTX':'FOF-ACF_MF-531������ֱ��5��m������2.0mm�����35��m','ZQUALIFIED':'��'}}";
//		JSONObject json = new JSONObject();
//		JSONObject header = new JSONObject();
//		JSONObject details = new JSONObject();
//		String BUKRS="";//��˾����
//		String BUTXT="";//��˾����
//		String LIFNR="";//��Ӧ��
//		String NAME1="";//��Ӧ������
//		String MATNR="";//���ϱ���
//		String MAKTX="";//��˾����
//		String ZQUALIFIED = "";//��Ӧ��״̬
//		
//		 try {
//			json.put("HEADER", header);
//			json.put("DETAILS", details);
//			JSONObject jo = new JSONObject(jsonStr);
//     		JSONObject head=jo.getJSONObject("HEADER");
//     		System.out.println(head.toString());
//     		BUKRS = head.getString("BUKRS");
//     		BUTXT = head.getString("BUTXT");
//     		LIFNR = head.getString("LIFNR");
//     		NAME1 = head.getString("NAME1");
//     		MATNR = head.getString("MATNR");
//     		MAKTX = head.getString("MAKTX");
//     		ZQUALIFIED = head.getString("ZQUALIFIED");
//     		
//     		header.put("companyCode", BUKRS);
//     		header.put("companyName", BUTXT);
//     		header.put("supplier", LIFNR);
//     		header.put("supplierName", NAME1);
//     		header.put("materialCode", MATNR);
//     		header.put("materialName", MAKTX);
//     		header.put("suplStatus", ZQUALIFIED);
//     		System.out.println(json.toString());
//     		
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//       	
//	}
	
	
//ec
//     public static void main (String[] args){
//    	 String jsonStr="{'HEADER':{'EBELN':'4500007170','BEDAT':'20170726','LIFNR':'1000978','NAME1':'�ӱ��¹⻪���޹�˾','EKORG':'G001','EKOTX':'��ɽ���Թ��ɹ���֯','EKGRP':'P01','EKNAM':'��ƽ','BUKRS':'1000','BUTXT':'��ɽ���Թ�����޹�˾','BRTWR':'6300.00'},'DETALIS':{'DT1':[{'EBELP':'00010','MATNR':'500000221','TXZ01':'ջ��_����,�ߴ磺1100X1100X150cm','MENGE':'70.000','MEINS':'��','EINDT':'20170726','NETPR':'76.92','KBETR':'90.00','WAERS':'CNY','MWSKZ':'J5','TEXT1':'17% ����˰���й�','PEINH':'1','BPRME':'��','NAME1':'���Թ����ɽ����','LGOBE':'','WGBEZ':'�����Ĳ�','AFNAM':'','INFNR':'5300008103','BANFN':'3500004268','BNFPO':'00010','KNTTP':'','PSTYP':'0','SAKTO':'','TXT20':'','KOSTL':'','LTEXT':'','AUFNR':'','KTEXT':'','ANLN1':'','ANLN2':'','BRTWR':'6300.00','LOEKZ':'','TXT50':''}]}}";
//    	 SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
//    	 String now = sf.format(new Date());
//    	 System.out.println(now);
//         String EBELN="";//�ɹ�������
//         String BEDAT="";//ƾ֤����
//         String LIFNR="";//��Ӧ��
//         String NAME1="";//��Ӧ������
//         String EKORG="";//�ɹ���֯
//         String EKOTX="";//�ɹ���֯��������
//         String EKGRP="";//�ɹ���
//         String EKNAM="";//�ɹ��飨������
//         String BUKRS="";//��˾����
//         String BUTXT="";//��˾����
//         String BRTWR = "";//�����ܽ��
//         //��ϸ1
//         String EBELP="";//��Ŀ
//         String MATNR="";//����
//         String TXZ01="";//���ı�
//         String MENGE="";//�ɹ���������
//         String MEINS="";//������λ
//         String EINDT="";//��������
//         String NETPR="";//����
//         String KBETR="";//��˰��
//         String WAERS="";//����
//         String MWSKZ="";//˰��
//         String PEINH="";//ÿ
//         String BPRME="";//�۸�λ
//         String NAME1_dt1="";//����
//         String LGOBE="";//���ص�
//         String WGBEZ="";//������
//         String AFNAM="";//������
//         String INFNR="";//�ɹ���Ϣ��¼
//         String BANFN="";//�ɹ�����
//         String BNFPO="";//������Ŀ
//         String KNTTP="";//��Ŀ�������
//         String PSTYP="";//��Ŀ���
//         String SAKTO="";//���˿�Ŀ
//         String KOSTL="";//�ɱ�����
//         String AUFNR="";//����
//         String ANLN1="";//�̶��ʲ����
//         String ANLN2="";//�μ����
//
// 		String TEXT1 = "";//˰������
// 		String TXT20 = "";//���˿�Ŀ����
// 		String LTEXT = "";//�ɱ���������
// 		String KTEXT = "";//��������
// 		String TXT50 = "";//�̶��ʲ�����
//         JSONObject json = new JSONObject();
// 		JSONObject header = new JSONObject();
// 		JSONObject details = new JSONObject();
//    	 try {
//            json.put("HEADER", header);
//    	 	json.put("DETAILS", details);
//			JSONObject jo = new JSONObject(jsonStr);
//			JSONObject head=jo.getJSONObject("HEADER");
//			System.out.println(head.toString());
//			EBELN=head.getString("EBELN");
//			BEDAT=head.getString("BEDAT");
//			LIFNR=head.getString("LIFNR");
//			NAME1=head.getString("NAME1");
//			EKORG=head.getString("EKORG");
//			EKOTX=head.getString("EKOTX");
//			EKGRP=head.getString("EKGRP");
//			EKNAM=head.getString("EKNAM");
//			BUKRS=head.getString("BUKRS");
//			BUTXT=head.getString("BUTXT");
//			BRTWR = head.getString("BRTWR");
//			header.put("orderNo", EBELN);
//			header.put("certifidate", BEDAT);
//			header.put("supplier", LIFNR);
//			header.put("supplierName", NAME1);
//			header.put("PurchaseOrg", EKORG);
//			header.put("PurOrgDesc", EKOTX);
//			header.put("PurchaseGro", EKGRP);
//			header.put("PurGroDesc", EKNAM);
//			header.put("companyCode", BUKRS);
//			header.put("companyName", BUTXT);
//			header.put("brtwr", BRTWR);
//			JSONObject dts = jo.getJSONObject("DETALIS");
//			JSONArray dt1 = dts.getJSONArray("DT1");
//			JSONArray dt11 = new JSONArray();
//			for(int i=0;i<dt1.length();i++){
//				JSONObject arr=dt1.getJSONObject(i);
//				JSONObject node=new JSONObject();
//				System.out.println(arr.toString());
//				 EBELP=arr.getString("EBELP");
//		         MATNR=arr.getString("MATNR");
//		         TXZ01=arr.getString("TXZ01");
//		         MENGE=arr.getString("MENGE");
//		         MEINS=arr.getString("MEINS");
//		         EINDT=arr.getString("EINDT");
//		         NETPR=arr.getString("NETPR");
//		         KBETR=arr.getString("KBETR");
//		         WAERS=arr.getString("WAERS");
//		         MWSKZ=arr.getString("MWSKZ");
//		         PEINH=arr.getString("PEINH");
//		         BPRME=arr.getString("BPRME");
//		         NAME1_dt1=arr.getString("NAME1");
//		         LGOBE=arr.getString("LGOBE");
//		         WGBEZ=arr.getString("WGBEZ");
//		         AFNAM=arr.getString("AFNAM");
//		         INFNR=arr.getString("INFNR");
//		         BANFN=arr.getString("BANFN");
//		         BNFPO=arr.getString("BNFPO");
//		         KNTTP=arr.getString("KNTTP");
//		         PSTYP=arr.getString("PSTYP");
//		         SAKTO=arr.getString("SAKTO");
//		         KOSTL=arr.getString("KOSTL");
//		         AUFNR=arr.getString("AUFNR");
//		         ANLN1=arr.getString("ANLN1");
//		         ANLN2=arr.getString("ANLN2");
//		         TEXT1 = arr.getString("TEXT1");
//					TXT20 = arr.getString("TXT20");
//					LTEXT = arr.getString("LTEXT");
//					KTEXT = arr.getString("KTEXT");
//					TXT50 = arr.getString("TXT50");
//		         node.put("project", EBELP);
//		         node.put("material", MATNR);
//		         node.put("shorttext", TXZ01);
//		         node.put("purordernum", MENGE);
//		         node.put("unit", MEINS);
//		         node.put("deliveryDate", EINDT);
//		         node.put("netprice", NETPR);
//		         node.put("hastaxprice", KBETR);
//		         node.put("currency", WAERS);
//		         node.put("taxCode", MWSKZ);
//		         node.put("PEINH", PEINH);
//		         node.put("priceUnit", BPRME);
//		         node.put("glant", NAME1_dt1);
//		         node.put("stolocation", LGOBE);
//		         node.put("materialGro", WGBEZ);
//		         node.put("Applicant", AFNAM);
//		         node.put("purrecord", INFNR);
//		         node.put("purrequest", BANFN);
//		         node.put("reqproject", BNFPO);
//		         node.put("asstype", KNTTP);
//		         node.put("protype", PSTYP);
//		         node.put("generAccount", SAKTO);
//		         node.put("costcenter", KOSTL);
//		         node.put("orders", AUFNR);
//		         node.put("assetNum", ANLN1);
//		         node.put("subNum", ANLN2);
//		         node.put("TEXT1", TEXT1);
//					node.put("TXT20", TXT20);
//					node.put("LTEXT", LTEXT);
//					node.put("KTEXT", KTEXT);
//					node.put("TXT50", TXT50);
//		         dt11.put(node);
//			}
//			details.put("DT1", dt11);
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//    	 System.out.println(json.toString());
//        
//     }
	 public static void main (String[] args){
		//String reqman="";
		String sqr="22";
		String sqrbm="33";
		String jsonStr="{'DETAILS':{'DT1':[{'ndkyys':'693730','fycd':'101','fyssqj':'2017-08-15','ydkyys':'95000','yssqje':'10000','jtsy':'','yskm':'263'}]},'HEADER':{'fycdbm':'700015','txr':'3448','szgs':'70000','sqr':'3448','sqrq':'2017-08-15','oarqid':'629513','fyys':''}}";
		String reqman="";//������Ա
		String mnyBearPsn="";//���óе��� 
		String mnyBearDept="";//���óе�����
		String reqdate="";//��������
		String reqsub="";//���ڹ�˾
		String eeramt="";//������
		String cneeramt="";//������
		String oarqid2="";//oarqid2
		//��ϸ
		String budgetmonth="";//���������ڼ�
		String budgettype="";//Ԥ������
		String costcenterid="";//���óе�
		String budgetaccountid="";//Ԥ���Ŀ
		String eeramt_dt="";//Ԥ��������
		String jtsy="";//��������
		String ndkyje="";//��ȿ��ý��
		
		JSONObject json = new JSONObject();
		JSONObject header = new JSONObject();
		JSONObject details = new JSONObject();
try{
		json.put("HEADER", header);
		json.put("DETAILS", details);
		JSONObject jo = new JSONObject(jsonStr);
		JSONObject head = jo.getJSONObject("HEADER");
		System.out.println(head.toString());
		System.out.println(head.getString("szgs"));
		//reqdate = Util.null2String(head.getString("sqrq"));
		mnyBearPsn = head.getString("sqr");
		System.out.println(head.getString("szgs"));
		mnyBearDept = head.getString("fycdbm");
		System.out.println("aaa"+oarqid2);
		reqsub = head.getString("szgs");
		System.out.println("aaa"+oarqid2);
		eeramt =head.getString("fyys");
		System.out.println("aaa"+oarqid2);
		cneeramt = head.getString("fyys");
		oarqid2 =  head.getString("oarqid");
		
		header.put("reqman", sqr);
		header.put("reqdate", reqdate);
		header.put("mnyBearPsn", mnyBearPsn);
		header.put("mnyBearDept", mnyBearDept);
		header.put("reqsub", reqsub);
		header.put("eeramt", eeramt);
		header.put("cneeramt", cneeramt);
		header.put("oarqid2", oarqid2);
		
		JSONObject dts = jo.getJSONObject("DETAILS");
		System.out.println(dts.toString());
		JSONArray dt1 = dts.getJSONArray("DT1");
		JSONArray dt11 = new JSONArray();
		for (int i = 0; i < dt1.length(); i++) {
			System.out.println("bbb");
			JSONObject arr = dt1.getJSONObject(i);
			JSONObject node = new JSONObject();
			budgetmonth = arr.getString("fyssqj");
			budgettype = "3";
			costcenterid = arr.getString("fycd");
			budgetaccountid = arr.getString("yskm");
			eeramt_dt = arr.getString("yssqje");
			jtsy = arr.getString("jtsy");
			ndkyje = arr.getString("ndkyys");
		    node.put("budgetmonth", budgetmonth);
		    node.put("budgettype", budgettype);
		    node.put("costcenterid", costcenterid);
		    node.put("budgetaccountid", budgetaccountid);
		    node.put("eeramt", eeramt_dt);
		    node.put("jtsy", jtsy);
		    node.put("ndkyje", ndkyje);
			
			dt11.put(node);
		}
		details.put("DT1", dt11);
	 } catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		System.out.println(json.toString());
	}
     
}
}
