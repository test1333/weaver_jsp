package gvo.webservice;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import weaver.general.BaseBean;

public class CreateRequestServiceOA extends BaseBean {
	public String CreateMaterialApproval(String workcode, String dataInfo) {
		BaseBean log = new BaseBean();
		log.writeLog("CreateMaterialApproval workcode:" + workcode
				+ " dataInfo:" + dataInfo);
		if ("".equals(workcode) || "".equals(dataInfo)) {
			Map<String, String> retMap = new HashMap<String, String>();
			retMap.put("MSG_TYPE", "E");
			retMap.put("MSG_CONTENT", "人员编号无法匹配");
			retMap.put("OA_ID", "0");
			log.writeLog("CreateMaterialApproval result:" + getJsonStr(retMap));
			return getJsonStr(retMap);
		}
		CreateRequestServiceOAImpl crso = new CreateRequestServiceOAImpl();
		String result = crso.doserviceMaterial(workcode, dataInfo);
		log.writeLog("CreateMaterialApproval result:" + result);
		return result;
	}

	public String CreateSupplierUpdate(String workcode, String dataInfo) {
		BaseBean log = new BaseBean();
		log.writeLog("CreateSupplierUpdate workcode:" + workcode + " dataInfo:"
				+ dataInfo);
		if ("".equals(workcode) || "".equals(dataInfo)) {
			Map<String, String> retMap = new HashMap<String, String>();
			retMap.put("MSG_TYPE", "E");
			retMap.put("MSG_CONTENT", "人员编号无法匹配");
			retMap.put("OA_ID", "0");
			log.writeLog("CreateSupplierUpdate result:" + getJsonStr(retMap));
			return getJsonStr(retMap);
		}
		CreateRequestServiceOAImpl crso = new CreateRequestServiceOAImpl();
		String result = crso.doserviceSupplier(workcode, dataInfo);
		log.writeLog("CreateSupplierUpdate result:" + result);
		return result;
	}
	public String CreateHR015Service(String workcode, String dataInfo) {
		BaseBean log = new BaseBean();
		log.writeLog("CreateHR015Service workcode:" + workcode + " dataInfo:"
				+ dataInfo);
		if ("".equals(workcode) || "".equals(dataInfo)) {
			Map<String, String> retMap = new HashMap<String, String>();
			retMap.put("MSG_TYPE", "E");
			retMap.put("MSG_CONTENT", "人员编号无法匹配");
			retMap.put("OA_ID", "0");
			log.writeLog("CreateHR015Service result:" + getJsonStr(retMap));
			return getJsonStr(retMap);
		}
		CreateRequestServiceOAImpl crso = new CreateRequestServiceOAImpl();
		String result = crso.doserviceHR015(workcode, dataInfo);
		log.writeLog("CreateHR015Service result:" + result);
		return result;
	}

	private String getJsonStr(Map<String, String> map) {
		JSONObject json = new JSONObject();
		Iterator<String> it = map.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			String value = map.get(key);
			try {
				json.put(key, value);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}

		return json.toString();
	}
}
