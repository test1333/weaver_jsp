package gvo.ecsysn;

import weaver.general.BaseBean;
import weaver.interfaces.schedule.BaseCronJob;

public class SysnGVOOrganize extends BaseCronJob{
	public void execute() { 
		BaseBean log = new BaseBean();
		log.writeLog("��֯ͬ����ʼ:");
		Ecsysnorganize esc = new Ecsysnorganize();
		EcRoles er = new EcRoles();
		esc.operSubCompany();
		esc.operDepartment();
		esc.operjobtitle();
		esc.operResource();
		er.sysRole();
		log.writeLog("��֯ͬ������:");
	}

}
