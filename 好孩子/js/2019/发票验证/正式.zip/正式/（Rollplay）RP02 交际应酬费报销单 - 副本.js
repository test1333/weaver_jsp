<script type="text/javascript">
var wbje="#field15419";
var sjje="#field_lable7006";
jQuery(document).ready(function(){
	jQuery(wbje).attr("readonly", "readonly");
	jQuery(sjje).attr("readonly", "readonly");
});
</script>	
